<?php
/**
 * Created by PhpStorm.
 * User: kim2
 * Date: 2019-04-04
 * Time: 오전 9:39
 */

if(isset($_POST[order_id]) && $_POST[name] != NULL){
# TODO: MySQL DB에서, POST로 받아온 내용 입력하기!
$connect = mysql_connect("localhost","lyj","1234");
mysql_select_db("lyj_db", $connect);


$sql = "insert into tableboard_shop set date = $_POST[date] ,order_id = $_POST[order_id], name= $_POST[name], price=$_POST[price], quantity=$_POST[quantity]";
mysql_query($sql);

mysql_close($connect);
# 참고 : 에러 메시지 출력 방법


    echo "<script> alert('insert okay!!') </script>";
}
else{
    echo "<script> alert('insert fail!!') </script>";
}
?>

<script>
    location.replace('../index.php');
</script>

# TableBoard_Shop
게시판-Shop 의 TODO 완성하기!

## 기존 파일
```
 .
├── css - board_form.php와 index.php 에서 사용하는 stylesheet
│   └── ...
├── fonts - 폰트
│   └── ...
├── images - 아이콘 이미지
│   └── ...
├── vender - 외부 라이브러리
│   └── ...
├── js - board_form.php와 index.php 에서 사용하는 javascript
│   └── ...
├── function
│   └── insert.php - 게시글 작성 기능 구현
│   └── update.php - 게시글 수정 기능 구현
│   └── delete.php - 게시글 삭제 기능 구현
├── board_form.php - 게시글 작성/수정 시 사용하는 form이 포함된 php 파일
├── index.php - 게시글 조회 기능 구현
```

## MySQL 테이블 생성!

[여기에 테이블 생성 시, 사용한 Query 를 작성하세요.]
create table tableboard_shop(
num int,
date char(20), 
order_id char(20), 
name char(20),
price float,
quantity int,
primary key(num));

- table 이름은 tableboard_shop 으로 생성
- 기본키는 num 으로, 그 외의 속성은 board_form.php 의 input 태그 name 에 표시된 속성 이름으로 생성
- 각 속성의 type 은 자유롭게 설정 (단, 입력되는 값의 타입과 일치해야 함)
    - ex) price -> int
    - ex) name -> char or varchar
    
## index.php 수정
[여기에 index.php 를 어떻게 수정했는지, 설명을 작성하세요.]
 $connect = mysql_connect("localhost","lyj","1234"); //mysql 서버 접속
    mysql_select_db("lyj_db", $connect); //데이터베이스 선택

    $sql = "select * from tableboard_shop"; //테이블 전송
    $result = mysql_query($sql); 


    mysql_close($connect); //닫기
    
    
    <?php
                            # TODO : 아래 표시되는 내용을, MySQL 테이블에 있는 레코드로 대체하기!
                            while($row = mysql_fetch_array($result)) { //저장되있는 데이터를 모두 한줄씩 추출한다. (반복문)
    
                                ?>
                                //있었던 예제문을 지우고 <? echo $row[date] ?> 로 반환된 데이터를 출력한다.
                                <tr onclick="location.href = ('board_form.php?num=0')">
                                    <td class="column1"><? echo $row[date] ?></td>  
                                    <td class="column2"><? echo $row[order_id] ?></td>
                                    <td class="column3"><?
                                        echo $row[name] ?></td>
                                    <td class="column4"><?
                                        echo $row[price] ?></td>
                                    <td class="column5"><?
                                        echo $row[quantity] ?></td>
                                    <td class="column6"><?
                                        echo $row[price] * $row[quantity] ?></td>  //price와 quantity의 곱으로 total을 구한다.
                                </tr>
    
                                <?
                            }
                        ?>
                        
                        //데이터베이스에 저장되어있는 데이터들을 출력합니다.
## function


#board_form.php 수정

#TODO: MySQL 테이블에서, num에 해당하는 레코드 가져오기
    $connect = mysql_connect("localhost","lyj","1234"); //index의 서버접속및데이터베이스 선택과 동일, DB열기
    mysql_select_db("lyj_db", $connect);

    $sql = "select * from tableboard_shop where num= $_GET[num]"; //특정 num번 데이터만 가져오기 때문에 num으로 지정
    $result = mysql_query($sql);//데이터를 저장
    $row = mysql_fetch_array($result);
    mysql_close($connect); //mysql닫기
    
    
### insert.php 수정
[여기에 insert.php 를 어떻게 수정했는지, 설명을 작성하세요.]

if(isset($_POST[order_id]) && $_POST[name] != NULL){
# TODO: MySQL DB에서, POST로 받아온 내용 입력하기!
$connect = mysql_connect("localhost","lyj","1234");
mysql_select_db("lyj_db", $connect);
//DB 연결

$sql = "insert into tableboard_shop set date = $_POST[date] ,order_id = $_POST[order_id], name= $_POST[name], price=$_POST[price], quantity=$_POST[quantity]";
mysql_query($sql);
//삽입문, board_form에서 보낸 입력된 정보들을 테이블에 삽입한다.

mysql_close($connect);
//mysql닫기
# 참고 : 에러 메시지 출력 방법


    echo "<script> alert('insert okay!!') </script>";
}
else{
    echo "<script> alert('insert fail!!') </script>";
}
//삽입 성공시 okay 실패시 fail 출력
### update.php 수정
[여기에 update.php 를 어떻게 수정했는지, 설명을 작성하세요.]
# TODO: MySQL DB에서, POST로 받아온 내용 입력하기!
    $connect = mysql_connect("localhost", "lyj", "1234");
    mysql_select_db("lyj_db", $connect);
    //DB 연결

    $sql = "update tableboard_shop set date = $_POST[date] ,order_id = $_POST[order_id], name= $_POST[name], price=$_POST[price], quantity=$_POST[quantity] where num = $_GET[num]";
    mysql_query($sql);
    //수정문, num(primarykey)로 수정할곳 확인 후 board_form에서 보낸 입력된 정보들을 수정한다.
    mysql_close($connect);
    //mysql닫기
# 참고 : 에러 메시지 출력 방법

    echo "<script> alert('update okay!!') </script>";

}
else{
    echo "<script> alert('update fail!!') </script>";
}
//수정 성공시 okay 실패시 fail 출력
### delete.php 수정
[여기에 delete.php 를 어떻게 수정했는지, 설명을 작성하세요.]
# TODO: MySQL DB에서, POST로 받아온 내용 입력하기!
    $connect = mysql_connect("localhost", "lyj", "1234");
    mysql_select_db("lyj_db", $connect);
    //DB 연결

    $sql = "delete from tableboard_shop where num = $_GET[num]";
    mysql_query($sql);
    //삭제문, num(primarykey)로 삭제할 곳 확인 후 삭제
    mysql_close($connect);
    //mysql닫기
# 참고 : 에러 메시지 출력 방법

    echo "<script> alert('delete okay!!') </script>";

}
else{
    echo "<script> alert('delete fail!!') </script>";
}
//삭제 성공시 okay 실패시 fail 출력
# boardz
게시판 검색 기능 완성하기

## 기존 파일
```
 .
├── css
│   └── style.css
├── src
│   └── boardz.css
├── board.html
```

## 추가 및 수정된 파일
```
 .
├── css
│   └── style.css
├── src
│   └── boardz.css
├── board.php (수정)
[만약 추가한 파일이 있으면, 내용 추가! 없으면 이 문구 삭제!]
```

## board.php (수정)

<?php

//db연결
$connect = mysql_connect("localhost","lyj","1234");
mysql_select_db("lyj_db", $connect);

//boardz테이블의 행의 수 세기
$sql = "select count(*) as cnt from boardz";
$result = mysql_query($sql);
$row =  mysql_fetch_array($result);
$cnt = $row[cnt];

$sql = "select * from boardz";

//검색창에 검색했을 경우
if(isset($_GET[search])){
    //검색단어 탐색
    //검색단어에 해당되는 수 세기
    $sql = "select count(*) as cnt from boardz where title like '%$_GET[search]%' ";
    $result = mysql_query($sql);
    $row =  mysql_fetch_array($result);
    $cnt = $row[cnt];
    $sql = "select * from boardz where title like '%$_GET[search]%'";
}
$result = mysql_query($sql);

mysql_close($connect);
?>

//-----------------------
<?php
                //행수가 1일경우
                if($cnt==1){
                    ?>
                    <ul>
                    <?php
                    $row = mysql_fetch_array($result);
                    //title유무 판별
                    if($row[title]!=null) { //제목 존재하면?>
                        <li>
                            <h1> <?echo  $row[title]; ?><!--제목출력--> </h1>
                            <br/> <!--뛰어쓰기--><!--그림출력-->
                            <? echo $row[contents ];?>
                            <img src="<?echo $row[image_url ];?>"/>
                        </li>
                    <?}
                    else{
                        ?>
                        <li>
                            <br/>
                            <? echo $row[contents ];?>
                            <img src="<?echo $row[image_url ];?>"/>
                        </li>
                        <?
                    }
                    ?>
                    </ul><?php
                }
                
                //행수가 2일경우
                elseif($cnt==2){
                    ?>
                    <?php
                    //title유무판별 2번반복
                    for($viewnum=0; $viewnum< $cnt; $viewwnum++){
                        ?>
                    <ul>
                    <?
                        $row = mysql_fetch_array($result);
                        if($row[title]!=null) { //제목 존재하면?>
                            <li>
                                <h1> <?echo  $row[title]; ?><!--제목출력--> </h1>
                                <br/> <!--뛰어쓰기--><!--그림출력-->
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                        <?}
                        else{
                            ?>
                            <li>
                                <br/>
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                            <?
                        }?>
                        </ul> <?php
                    }
                }
                //행수가 3이상일때 행수를 3으로 나누어 데이터들을 세줄로 출력
                따라서 반복문도 세개로 나눠줌
                else{
                    $viewnum=0;
                    ?>
                    <ul>
                    <?php
                    for($viewnum; $viewnum< $cnt/3; $viewnum++){
                        $row = mysql_fetch_array($result);
                        if($row[title]!=null) { ?>
                            <li>
                                <h1> <?echo  $row[title]; ?> </h1>
                                <br/>
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                        <?}
                        else{
                            ?>
                            <li>
                                <br/>
                                <? echo $row[contents];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                            <?
                        }
                    }
                    ?>
                    </ul>
                    <ul>
                        <?php
                        for($viewnum; $viewnum< $cnt/3*2; $viewnum++){
                            $row = mysql_fetch_array($result);
                            if($row[title]!=null) { ?>
                                <li>
                                    <h1> <?echo  $row[title]; ?> </h1>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                            <?}
                            else{
                                ?>
                                <li>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                                <?
                            }
                        }
                        ?>
                    </ul>
                    <ul>
                        <?php
                        for($viewnum; $viewnum< $cnt; $viewnum++){
                            $row = mysql_fetch_array($result);
                            if($row[title]!=null) { ?>
                                <li>
                                    <h1> <?echo  $row[title]; ?> </h1>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                            <?}
                            else{
                                ?>
                                <li>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                                <?
                            }
                        }
                        ?>
                    </ul>

                    <?php
                }
                ?>


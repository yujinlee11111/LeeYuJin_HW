<!-- 구글 검색 : galley board css => CSS Only Pinterest-like Responsive Board Layout - Boardz.css | CSS ... -->
<!-- 출처 : https://www.cssscript.com/css-pinterest-like-responsive-board-layout-boardz-css/ -->
<?php
$connect = mysql_connect("localhost","lyj","1234");
mysql_select_db("lyj_db", $connect);

$sql = "select count(*) as cnt from boardz";
$result = mysql_query($sql);
$row =  mysql_fetch_array($result);
$cnt = $row[cnt];

$sql = "select * from boardz";

if(isset($_GET[search])){
    $sql = "select count(*) as cnt from boardz where title like '%$_GET[search]%' ";
    $result = mysql_query($sql);
    $row =  mysql_fetch_array($result);
    $cnt = $row[cnt];
    $sql = "select * from boardz where title like '%$_GET[search]%'";
}
$result = mysql_query($sql);

mysql_close($connect);
?>
<!doctype html>

<html lang="en">
<head>
    <meta charset="UTF-8"> 

    <title>Boardz Demo</title>
    <meta name="description" content="Create Pinterest-like boards with pure CSS, in less than 1kB.">
    <meta name="author" content="Burak Karakan">
    <meta name="viewport" content="width=device-width; initial-scale = 1.0; maximum-scale=1.0; user-scalable=no" />
    <link rel="stylesheet" href="src/boardz.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/wingcss/0.1.8/wing.min.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
    <div class="seventyfive-percent  centered-block">
        <!-- Sample code block -->
        <div>    
            <hr class="seperator">

            <!-- Example header and explanation -->
            <div class="text-center">
                <h2>Beautiful <strong>Boardz</strong></h2>
                <div style="display: block; width: 50%; margin-right: auto; margin-left: auto; position: relative;">
                    <form class="example" action="board.php">
                        <input type="text" placeholder="Search.." name="search">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
            </div>

            <!--<hr class="seperator fifty-percent">-->

            <!-- Example Boardz element. -->
            <div class="boardz centered-block beautiful">

                <?php
                if($cnt==1){
                    ?>
                    <ul>
                    <?php
                    $row = mysql_fetch_array($result);
                    if($row[title]!=null) { //제목 존재하면?>
                        <li>
                            <h1> <?echo  $row[title]; ?><!--제목출력--> </h1>
                            <br/> <!--뛰어쓰기--><!--그림출력-->
                            <? echo $row[contents ];?>
                            <img src="<?echo $row[image_url ];?>"/>
                        </li>
                    <?}
                    else{
                        ?>
                        <li>
                            <br/>
                            <? echo $row[contents ];?>
                            <img src="<?echo $row[image_url ];?>"/>
                        </li>
                        <?
                    }
                    ?>
                    </ul><?php
                }
                elseif($cnt==2){
                    ?>
                    <?php
                    for($viewnum=0; $viewnum< $cnt; $viewwnum++){
                        ?>
                    <ul>
                    <?
                        $row = mysql_fetch_array($result);
                        if($row[title]!=null) { //제목 존재하면?>
                            <li>
                                <h1> <?echo  $row[title]; ?><!--제목출력--> </h1>
                                <br/> <!--뛰어쓰기--><!--그림출력-->
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                        <?}
                        else{
                            ?>
                            <li>
                                <br/>
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                            <?
                        }?>
                        </ul> <?php
                    }
                }
                else{
                    $viewnum=0;
                    ?>
                    <ul>
                    <?php
                    for($viewnum; $viewnum< $cnt/3; $viewnum++){
                        $row = mysql_fetch_array($result);
                        if($row[title]!=null) { ?>
                            <li>
                                <h1> <?echo  $row[title]; ?> </h1>
                                <br/>
                                <? echo $row[contents ];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                        <?}
                        else{
                            ?>
                            <li>
                                <br/>
                                <? echo $row[contents];?>
                                <img src="<?echo $row[image_url ];?>"/>
                            </li>
                            <?
                        }
                    }
                    ?>
                    </ul>
                    <ul>
                        <?php
                        for($viewnum; $viewnum< $cnt/3*2; $viewnum++){
                            $row = mysql_fetch_array($result);
                            if($row[title]!=null) { ?>
                                <li>
                                    <h1> <?echo  $row[title]; ?> </h1>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                            <?}
                            else{
                                ?>
                                <li>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                                <?
                            }
                        }
                        ?>
                    </ul>
                    <ul>
                        <?php
                        for($viewnum; $viewnum< $cnt; $viewnum++){
                            $row = mysql_fetch_array($result);
                            if($row[title]!=null) { ?>
                                <li>
                                    <h1> <?echo  $row[title]; ?> </h1>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                            <?}
                            else{
                                ?>
                                <li>
                                    <br/>
                                    <? echo $row[contents ];?>
                                    <img src="<?echo $row[image_url ];?>"/>
                                </li>
                                <?
                            }
                        }
                        ?>
                    </ul>

                    <?php
                }
                ?>


            </div>
        </div>

        <hr class="seperator">

    </div>
</body>
</html>